#!/bin/bash

# Install dependencies
pip install -r requirements.txt

# Generate PGP keys if they don't exist
if [ ! -f "config/pgp_keys/public_key.pem" ] || [ ! -f "config/pgp_keys/private_key.pem" ]; then
    echo "Generating PGP keys..."
    gpg --batch --generate-key <(cat <<EOF
        Key-Type: RSA
        Key-Length: 2048
        Subkey-Type: RSA
        Subkey-Length: 2048
        Name-Real: Operator
        Name-Comment: GHOST-COM Network
        Name-Email: operator@ghost-com.net
        Expire-Date: 0
        %commit
EOF
    )
    gpg --export-secret-keys operator@ghost-com.net > config/pgp_keys/private_key.pem
    gpg --export operator@ghost-com.net > config/pgp_keys/public_key.pem
fi

# Run the GHOST-COM Network
python src/ghost_com.py
