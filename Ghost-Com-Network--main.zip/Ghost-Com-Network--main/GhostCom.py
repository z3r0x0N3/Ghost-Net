import time
import os
from encryption import encrypt_aes, encrypt_pgp, decrypt_pgp, decrypt_aes, generate_shift_keyword, hash_data
from proxy_chain import setup_proxy_chain, send_to_primary_node
from tor_utils import renew_tor_identity, generate_onion_address

def ghost_com_operation():
    while True:
        # Renew Tor identity and generate new onion address
        renew_tor_identity()
        new_onion_address = generate_onion_address()

        # Generate lock-cycle payload
        keywords = [generate_shift_keyword() for _ in range(3)]
        algorithms = [hash_data('random_data', algorithm=alg) for alg in ['sha256', 'sha512', 'md5']]
        node_order = list(range(3))
        random.shuffle(node_order)

        # Encrypt lock-cycle payload
        payload = f"{''.join(keywords)},{','.join(algorithms)},{','.join(map(str, node_order))}"
        aes_key = os.urandom(32)
        encrypted_payload = encrypt_aes(payload, aes_key)
        pgp_encrypted_payload = encrypt_pgp(encrypted_payload, open('config/pgp_keys/public_key.pem').read())

        # Send encrypted payload to primary node
        send_to_primary_node(pgp_encrypted_payload)

        # Wait for 60 seconds before regenerating the payload
        time.sleep(60)

if __name__ == "__main__":
    ghost_com_operation()
