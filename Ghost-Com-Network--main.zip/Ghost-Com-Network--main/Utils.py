import random

def random_choice(choices):
    return random.choice(choices)
